/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package main;

import Login.Login;
import Login.controllerLogin;
import Login.menuModel;


/**
 *
 * @author HP
 */
public class main_view {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        menuModel model = new menuModel();
        Login view = new Login();
        controllerLogin controller = new controllerLogin(model,view);
    }
}