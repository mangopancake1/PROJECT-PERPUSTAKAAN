/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pengembalian;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import Menu.menu;
/**
 *
 * @author ASUS
 */
public class Kembali extends JFrame{
    controllerKembali dk;
    public Kembali(){
        initComponents();
        dk = new controllerKembali(this);
        dk.isitable();
    }
    
    private JTextField nama, nomor,judul, penerbit, penulis, tahun, kategori;
    private JButton simpan,kembali;
    private void initComponents() {
        JPanel leftPanel = new JPanel(new BorderLayout());
        tabelDataBuku = new JTable();

        tabelDataBuku.setModel(new javax.swing.table.DefaultTableModel(
                new Object [][] {
                        {null, null, null, null},
                        {null, null, null, null},
                        {null, null, null, null},
                        {null, null, null, null},
                        {null, null, null, null},
                        {null, null, null, null},
                        {null, null, null, null}
                },
                new String [] {
                        "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7"
                }
        ));
        tabelDataBuku.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ActionEvent dummyEvent = new ActionEvent(tabelDataBuku, ActionEvent.ACTION_PERFORMED, "");
                tabelDataBukuMouseClicked(dummyEvent);
            }
        });
        JScrollPane scrollPane = new JScrollPane(tabelDataBuku);
        leftPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));

        JPanel Panel = new JPanel(new GridLayout(0, 1, 5, 5));
        Panel.add(new JLabel("Judul"));
        judul = new JTextField(20);
        Panel.add(judul);
        
        Panel.add(new JLabel("Penerbit"));
        penerbit = new JTextField(20);
        Panel.add(penerbit);

        Panel.add(new JLabel("Penulis"));
        penulis = new JTextField(20);
        Panel.add(penulis);
        
        Panel.add(new JLabel("Tahun Terbit"));
        tahun = new JTextField(20);
        Panel.add(tahun);
        
        Panel.add(new JLabel("Kategori"));
        kategori = new JTextField(20);
        Panel.add(kategori);
        rightPanel.add(Panel);
        
        JPanel jPanel = new JPanel(new GridLayout(5, 1, 5, 5));
        simpan = new JButton("Simpan");
        jPanel.add(simpan);
        kembali = new JButton("Kembali");
        jPanel.add(kembali);
        rightPanel.add(jPanel);
        
        simpan.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                delete();
                create();
            }
        });
        kembali.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kembali();
            }
        });
        
        setLayout(new BorderLayout());
        add(leftPanel, BorderLayout.CENTER);
        add(rightPanel, BorderLayout.EAST);
        
        setTitle("Peminjaman");
        setSize(1200, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    private void create() {
        dk.create();
        dk.isitable();
        
        JOptionPane.showMessageDialog(this, "Buku Berhasil Dikembalikan");
        clearFields();
    }
    private void delete() {
        dk.hapus();
        dk.isitable();
    }
    private void kembali() {
        String username = null;
        JFrame menu = new menu(username);
        menu.setVisible(true);
        this.dispose();
    }
    
    private void tabelDataBukuMouseClicked(java.awt.event.ActionEvent evt){
        int baris = tabelDataBuku.getSelectedRow();
        judul.setText(tabelDataBuku.getValueAt(baris,2).toString());
        penerbit.setText(tabelDataBuku.getValueAt(baris,3).toString());
        penulis.setText(tabelDataBuku.getValueAt(baris,4).toString());
        tahun.setText(tabelDataBuku.getValueAt(baris,5).toString());
        kategori.setText(tabelDataBuku.getValueAt(baris,6).toString());
    }
    
    private void clearFields() {
        judul.setText("");
        penerbit.setText("");
        penulis.setText("");
        tahun.setText("");
        kategori.setText("");
    }
    
    
    
    
    private javax.swing.JTable tabelDataBuku;
    public JTable getBukuPinjam() {
        return tabelDataBuku;
    }
    public String getNama() {
        return nama.getText();
    }
    public String getNomor() {
        return nomor.getText();
    }
    public String getJudul() {
        return judul.getText();
    }
    public String getPenerbit() {
        return penerbit.getText();
    }
    public String getPenulis() {
        return penulis.getText();
    }
    public String getTahun() {
        return tahun.getText();
    }
    public String getKategori(){
        return kategori.getText();
    }
}
