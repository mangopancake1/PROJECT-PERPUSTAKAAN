/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tambah;
import java.util.List;
import perpustakaan.*;
/**
 *
 * @author ASUS
 */
public class controllerTambah {
    Tambahdata frame;
    DAOImTambah ImPinjam;
    List<dataBuku> dp;
    public controllerTambah(Tambahdata frame){
        this.frame = frame;
        ImPinjam = new DAOTambah();
        dp = ImPinjam.getALL();
    }
    public void create(){
        dataBuku dp = new dataBuku();
        dp.setJudul(frame.getJudul());
        dp.setPenerbit(frame.getPenerbit());
        dp.setPenulis(frame.getPenulis());
        dp.setTahun(Integer.parseInt(frame.getTahun()));
        dp.setKategori(frame.getKategori());
        ImPinjam.create(dp);
    }
    public void update(){
        dataBuku dp = new dataBuku();
        dp.setJudul(frame.getJudul());
        dp.setPenerbit(frame.getPenerbit());
        dp.setPenulis(frame.getPenulis());
        dp.setTahun(Integer.parseInt(frame.getTahun()));
        dp.setKategori(frame.getKategori());
        ImPinjam.update(dp);
    }
    public void delete() {
        dataBuku dp = new dataBuku();
        dp.setJudul(frame.getJudul());
        ImPinjam.delete(dp);
    }
    public void isitable(){
        dp = ImPinjam.getALL();
        tabelBuku mp = new tabelBuku(dp);
        frame.getBukuTable().setModel(mp);
    }
}
