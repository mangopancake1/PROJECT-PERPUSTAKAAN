/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Login;

import java.sql.*;
import javax.swing.*;
import koneksi.connector;
import Menu.menu;

/**
 *
 * @author Lenovo
 */
public class menuModel {
    
    Connection connection;
    Statement statement;
    
    public menuModel(){
        connection = connector.connection();
    }

    
    
    public void loginUser(String username, String password){
        try {
            String query = "SELECT * FROM `login` WHERE `username` = '" +username+"' AND `password` = '" +password+ "' ";
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            if(resultSet.next()){
                menu menuView = new menu(username);
                
            }
            else{
                JOptionPane.showMessageDialog(null, "Username atau Password salah", "Login Error", JOptionPane.ERROR_MESSAGE);
                menuModel model = new menuModel();
                Login view = new Login();
                controllerLogin controller = new controllerLogin(model,view);
            }
        } catch (Exception e) {
            System.out.println("Error : " + e.getMessage());
        }
    
    }
}
